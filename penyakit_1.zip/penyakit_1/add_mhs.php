<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

$conn = mysqli_connect('localhost', 'root', '', 'akademik');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nim = $_POST['nim'];
    $nama_mhs = $_POST['nama_mhs'];
    $jurusan = $_POST['jurusan'];

    $kueri = "INSERT INTO mahasiswa (nim, nama_mhs, jurusan) VALUES ('$nim', '$nama_mhs', '$jurusan')";
    $hasil = mysqli_query($conn, $kueri);

    if ($hasil) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false]);
    }
}

mysqli_close($conn);
?>
